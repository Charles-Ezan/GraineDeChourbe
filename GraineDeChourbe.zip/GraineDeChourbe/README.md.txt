# Exercice #1

Riwan Le Gal /
Charles Ezan

## Lancement

Executable disponible dans le dossier Release

Appuyer sur le bouton launch pour créer les pigeons, il est ensuite possible de faire
apparaitre des graines en cliquant sur la fenêtre.



## License
[MIT](https://choosealicense.com/licenses/mit/)